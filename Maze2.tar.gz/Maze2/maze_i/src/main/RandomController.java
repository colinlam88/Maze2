import uk.ac.warwick.dcs.maze.logic.*;
import java.awt.Point;

public class RandomController implements IRobotController {
    // the robot in the maze
    private IRobot robot;
    // a flag to indicate whether we are looking for a path
    private boolean active = false;
    // a value (in ms) indicating how long we should wait
    // between moves
    private int delay;

    // this method is called when the "start" button is clicked
    // in the user interface
    public void start() {
        this.active = true;

        // loop while we haven't found the exit and the agent
        // has not been interrupted
        while(!robot.getLocation().equals(robot.getTargetLocation()) && active) {
            // generate a random number between 0-3 (inclusive)
            int rand = (int)Math.floor(Math.random()*4);
            // generate a random number between 0-6 (inclusive)
            int rand2= (int)Math.floor(Math.random()*7);
            // introduce the variable x to make the logging work
            int x=0;
            if (rand2 <5 || rand2==5) {
              // 5 in 6 moves the robot would go into this, plus the probabilty to go into case 0 in the following code,
              //that would make a total of seven in eight moves to not change direction (one in eight moves to change)
              robot.face(IRobot.AHEAD);
                if (robot.look(IRobot.AHEAD)!=IRobot.WALL) {
                robot.advance();
                  }
            }
            else {
              // turn into one of the four directions, as determined
              // by the random number that was generated:
              // 0: ahead
              // 1: left
              // 2: right
              // 3: behind

              //The variable x is used to record which turn the robot has made,
              //so that we can log that turn later

              //turn randomly to one direction
              switch (rand) {
              case 0:
                  robot.face(IRobot.AHEAD);
                  break;
              case 1:
                  robot.face(IRobot.LEFT);
                  x=1;
                  break;
              case 2:
                  robot.face(IRobot.RIGHT);
                  x=2;
                  break;
              case 3:
                  robot.face(IRobot.BEHIND);
                  x=3;
                  break;
              }
            }
            //if there is not a wall ahead,
            // move one step into the direction the robot is facing
            if (robot.look(IRobot.AHEAD)!=IRobot.WALL) {
              robot.advance();
            }

            //log the moves according to the value of x
            if (x==0) {robot.getLogger().log(IRobot.AHEAD);}
            if (x==1) {robot.getLogger().log(IRobot.LEFT);}
            if (x==2) {robot.getLogger().log(IRobot.RIGHT);}
            if (x==3) {robot.getLogger().log(IRobot.BEHIND);}

            // wait for a while if we are supposed to
            if (delay > 0)
                robot.sleep(delay);
       }

    }

    // this method returns a description of this controller
    public String getDescription() {
       return "A controller which randomly chooses where to go";
    }

    // sets the delay
    public void setDelay(int millis) {
       delay = millis;
    }

    // gets the current delay
    public int getDelay() {
       return delay;
    }

    // stops the controller
    public void reset() {
       active = false;
    }

    // sets the reference to the robot
    public void setRobot(IRobot robot) {
       this.robot = robot;
    }
}
