import uk.ac.warwick.dcs.maze.logic.*;
import java.awt.Point;

public class HomingController implements IRobotController {
    // the robot in the maze
    private IRobot robot;
    // a flag to indicate whether we are looking for a path
    private boolean active = false;
    // a value (in ms) indicating how long we should wait
    // between moves
    private int delay;

    // this method is called when the "start" button is clicked
    // in the user interface
    public void start() {
        this.active = true;
        // if the robot hasn't reached the target
        //continue the loop
        while(!robot.getLocation().equals(robot.getTargetLocation()) && active) {

        int direction;
        int randno;

        direction = robot.look(IRobot.AHEAD);

        do {
            //generate a random number in the range of 0-2(inclusive)
            randno = (int) Math.round(Math.random()*3);

            // change the direction based on the random number
            if (randno == 0)
                direction = IRobot.LEFT;
            else if (randno == 1)
                direction = IRobot.RIGHT;
            else if (randno == 2)
                direction = IRobot.BEHIND;
            else
                direction = IRobot.AHEAD;

            // wait for a while if we are supposed to
            if (delay > 0)
                robot.sleep(delay);
            //face that direction
            robot.face(direction);
            //if there is a wall ahead, go back to the start of the loop
            //and pick a direction again
        } while (robot.look(IRobot.AHEAD)==IRobot.WALL);
        // move a step forward
        robot.advance();
      }
    }

    // this method returns 1 if the target is north of the
    // robot, -1 if the target is south of the robot, or
    // 0 if otherwise.
    public byte isTargetNorth() {
      if (robot.getLocation().y < robot.getTargetLocation().y) {          //if the y-coordinate of the target is larger than
          return -1;                                                      //that of the robot, the target is south of the robot
      } else if (robot.getLocation().y > robot.getTargetLocation().y) {   //as the upper-left corner of the maze has coordinate
          return 1;                                                       //(1,1), lower-right (n,n)
      } else {
          return 0;
      }

    }



    // this method returns 1 if the target is east of the
    // robot, -1 if the target is west of the robot, or
    // 0 if otherwise.
    public byte isTargetEast() {
      if (robot.getLocation().x > robot.getTargetLocation().x) {          //if the x-coordinate of the target is larger than
          return -1;                                                      //that of the robot, the target is east of the robot
      } else if (robot.getLocation().x < robot.getTargetLocation().x) {   //as the upper-left corner of the maze has coordinate
          return 1;                                                       //(1,1), lower-right (n,n)
      } else {
          return 0;
      }
    }

    // this method causes the robot to look to the absolute
    // direction that is specified as argument and returns
    // what sort of square there is
    public int lookHeading(int absoluteDirection) {

  int number = 0;
    //this integer variable is used to record which case the robot is in
    //which absolute direction the robot is facing
  if (robot.getHeading() == IRobot.NORTH) {
    number = 1;
  } else if (robot.getHeading() == IRobot.EAST) {
    number = 2;
  } else if (robot.getHeading() == IRobot.SOUTH) {
    number = 3;
  } else if (robot.getHeading() == IRobot.WEST) {
    number = 4;
  }
    //According to which absolute direction the robot's facing
    //pairing up the relative direction and absolute direction
  switch (number) {
    case 1:
      if (absoluteDirection == IRobot.NORTH) {
        return robot.look(IRobot.AHEAD);
      } else if (absoluteDirection == IRobot.EAST) {
        return robot.look(IRobot.RIGHT);
      } else if (absoluteDirection == IRobot.SOUTH) {
        return robot.look(IRobot.BEHIND);
      } else {
        return robot.look(IRobot.LEFT);
      }


    case 2:
      if (absoluteDirection == IRobot.NORTH) {
        return robot.look(IRobot.LEFT);
      } else if (absoluteDirection == IRobot.EAST) {
        return robot.look(IRobot.AHEAD);
      } else if (absoluteDirection == IRobot.SOUTH) {
        return robot.look(IRobot.RIGHT);
      } else {
        return robot.look(IRobot.BEHIND);
      }


    case 3:
      if (absoluteDirection == IRobot.NORTH) {
        return robot.look(IRobot.BEHIND);
      } else if (absoluteDirection == IRobot.EAST) {
        return robot.look(IRobot.LEFT);
      } else if (absoluteDirection == IRobot.SOUTH) {
        return robot.look(IRobot.AHEAD);
      } else {
        return robot.look(IRobot.RIGHT);
      }


    case 4:
      if (absoluteDirection == IRobot.NORTH) {
        return robot.look(IRobot.RIGHT);
      } else if (absoluteDirection == IRobot.EAST) {
        return robot.look(IRobot.BEHIND);
      } else if (absoluteDirection == IRobot.SOUTH) {
        return robot.look(IRobot.LEFT);
      } else {
        return robot.look(IRobot.AHEAD);
      }


      default:
        return 0;
  }
}


// *** this method causes the robot to face to the absolute
// direction that is specified as argument and returns
// what sort of square there is
// this is derived from the lookheading method
// this is used to let the robot face the absolute direction we want
public int faceHeading(int absoluteDirection) {

int number = 0;
//this variable is used to record which absolute direction the robot's facing
if (robot.getHeading() == IRobot.NORTH) {
number = 1;
} else if (robot.getHeading() == IRobot.EAST) {
number = 2;
} else if (robot.getHeading() == IRobot.SOUTH) {
number = 3;
} else if (robot.getHeading() == IRobot.WEST) {
number = 4;
}

//According to which absolute direction the robot's facing
//pairing up the relative and absolute direction
switch (number) {
case 1:
  if (absoluteDirection == IRobot.NORTH) {
    robot.face(IRobot.AHEAD);
  } else if (absoluteDirection == IRobot.EAST) {
    robot.face(IRobot.RIGHT);
  } else if (absoluteDirection == IRobot.SOUTH) {
    robot.face(IRobot.BEHIND);
  } else {
    robot.face(IRobot.LEFT);
  }
  break;


case 2:
  if (absoluteDirection == IRobot.NORTH) {
    robot.face(IRobot.LEFT);
  } else if (absoluteDirection == IRobot.EAST) {
    robot.face(IRobot.AHEAD);
  } else if (absoluteDirection == IRobot.SOUTH) {
    robot.face(IRobot.RIGHT);
  } else {
    robot.face(IRobot.BEHIND);
  }
  break;


case 3:
  if (absoluteDirection == IRobot.NORTH) {
    robot.face(IRobot.BEHIND);
  } else if (absoluteDirection == IRobot.EAST) {
    robot.face(IRobot.LEFT);
  } else if (absoluteDirection == IRobot.SOUTH) {
    robot.face(IRobot.AHEAD);
  } else {
    robot.face(IRobot.RIGHT);
  }
  break;


case 4:
  if (absoluteDirection == IRobot.NORTH) {
    robot.face(IRobot.RIGHT);
  } else if (absoluteDirection == IRobot.EAST) {
    robot.face(IRobot.BEHIND);
  } else if (absoluteDirection == IRobot.SOUTH) {
    robot.face(IRobot.LEFT);
  } else {
    robot.face(IRobot.AHEAD);
  }
  break;


  default:
    return 0;
}return 0;
}

    // this method determines the heading in which the robot
    // should head next to move closer to the target
    public int determineHeading() {

      //use a variable to record the relative bearing of the target to the robot
      //(south-west, north-east, north etc.)
      //using the isTargetNorth and isTargetEast function to work out the cardinal or intercardinal directions
      //with the robot being the centre

      int casenumber=0;

      if(isTargetNorth()==1 && isTargetEast()==1) {              //the target is to the north-east of the robot
        casenumber=1;
      }else if(isTargetNorth()==1 && isTargetEast()==-1) {
        casenumber=2;
      }else if(isTargetNorth()==-1 && isTargetEast()==1) {
        casenumber=3;
      }else if(isTargetNorth()==-1 && isTargetEast()==-1) {
        casenumber=4;
      }else if(isTargetNorth()==1 && isTargetEast()==0) {
        casenumber=5;
      }else if(isTargetNorth()==-1 && isTargetEast()==0) {
        casenumber=6;
      }else if(isTargetNorth()==0 && isTargetEast()==1) {       //the target is to the east of the robot
        casenumber=7;
      }else if(isTargetNorth()==0 && isTargetEast()==-1) {
        casenumber=8;
      }

      int north =0;
      int east =0;
      int south =0;
      int west =0;
      //if there's not a wall to that direction
      //the variables will record a value
      //the numbers 1,2,4,7 are used so that the case numbers
      //will not repeat in the following switch function
      if(lookHeading(IRobot.NORTH)!=IRobot.WALL) {
        north=1;
      }
      if(lookHeading(IRobot.EAST)!=IRobot.WALL) {
        east=2;
      }
      if(lookHeading(IRobot.SOUTH)!=IRobot.WALL) {
        south=4;
      }
      if(lookHeading(IRobot.WEST)!=IRobot.WALL) {
        west=7;
      }

      int casenumberinside =0; //another case number variable is introduced, it will be used to cater the switch inside the switch
                               //recording the cases of whether or not there is a wall in those two directions. None, both or only one
      switch(north+east) {
        case 3:                //there isn't a wall in both the north and east direction
          casenumberinside=1;
          break;
        case 1:                //there isn't a wall in the north but there's a wall in the east
          casenumberinside=2;
          break;
        case 2:                //there isn't a wall in the east but there's a wall in the north
          casenumberinside=3;
          break;
        case 0:                //there are walls in both the north and east
          casenumberinside=4;
          break;
      }

      switch(north+west) {
        case 8:                // same logic as above, please refer to what number each direction is assigned
          casenumberinside=5;
          break;
        case 1:
          casenumberinside=6;
          break;
        case 7:
          casenumberinside=7;
          break;
        case 0:
          casenumberinside=8;
          break;
      }

      switch(south+east) {
        case 6:
          casenumberinside=9;
          break;
        case 4:
          casenumberinside=10;
          break;
        case 2:
          casenumberinside=11;
          break;
        case 0:
          casenumberinside=12;
          break;
      }

      switch(south+west) {
        case 11:
          casenumberinside=13;
          break;
        case 4:
          casenumberinside=14;
          break;
        case 7:
          casenumberinside=15;
          break;
        case 0:
          casenumberinside=16;
          break;
      }

      switch(east+south+west) {                            //three direction, for north
        case 13:
          casenumberinside=17;
          break;
        case 11:
          casenumberinside=18;
          break;
        case 9:
          casenumberinside=19;
          break;
        case 6:
          casenumberinside=20;
          break;
        case 2:
          casenumberinside=21;
          break;
        case 4:
          casenumberinside=22;
          break;
        case 7:
          casenumberinside=23;
          break;
      }

      switch(north+south+west) {                            //three direction, for east
        case 12:
          casenumberinside=24;
          break;
        case 11:
          casenumberinside=25;
          break;
        case 8:
          casenumberinside=26;
          break;
        case 5:
          casenumberinside=27;
          break;
        case 1:
          casenumberinside=28;
          break;
        case 4:
          casenumberinside=29;
          break;
        case 7:
          casenumberinside=30;
          break;
      }

      switch(north+east+west) {                            //three direction, for south
        case 10:
          casenumberinside=31;
          break;
        case 9:
          casenumberinside=32;
          break;
        case 8:
          casenumberinside=33;
          break;
        case 3:
          casenumberinside=34;
          break;
        case 1:
          casenumberinside=35;
          break;
        case 2:
          casenumberinside=36;
          break;
        case 7:
          casenumberinside=37;
          break;
      }

      switch(north+east+south) {                            //three direction, for west
        case 7:
          casenumberinside=38;
          break;
        case 6:
          casenumberinside=39;
          break;
        case 5:
          casenumberinside=40;
          break;
        case 3:
          casenumberinside=41;
          break;
        case 1:
          casenumberinside=42;
          break;
        case 2:
          casenumberinside=43;
          break;
        case 4:
          casenumberinside=44;
          break;
      }

      // generate a random number between 0-1 (inclusive)
      int rand3 = (int)Math.floor(Math.random()*2);
      // generate a random number between 0-2 (inclusive)
      int rand4 = (int)Math.floor(Math.random()*3);

      // Start of the selection tree.
      // Outmost switch helps determining in which direction relative to the robot, the target is
      // the inner switch helps us determine to which direction of the robot the walls are located
      // and subsequently pick which direction to face
      // according to the principles:
      // 1. move closer to the target
      // 2. should not face a wall
      // 3. If two routes are equally available, randomly pick one
      // 4. If no routes can make you closer to the target, randomly pick one

      switch (casenumber) {
        case 1:                                               //the target is to the north-east of the robot
            switch(casenumberinside) {
              case 1:                                         //there isn't a wall in both the north and east direction
                  if (rand3==1) {                             //randomly pick north or east to face
                    faceHeading(IRobot.NORTH);
                  }else {faceHeading(IRobot.EAST);
                    }
                    break;
              case 2:                                         //there isn't a wall in the north but there's a wall in the east
                  faceHeading(IRobot.NORTH);                  //face North
                  break;
              case 3:                                         //there isn't a wall in the east but there's a wall in the north
                  faceHeading(IRobot.EAST);                   //face East
                  break;
              case 4:                                         //there is a wall in both north and east
                  switch(casenumberinside) {                  //need to choose between south and west, see if there is a
                    case 13:                                  //wall in those direction, if both is okay to move towards
                        if (rand3==1) {                       //randomly pick one
                          faceHeading(IRobot.SOUTH);
                        }else {faceHeading(IRobot.WEST);
                          }
                        break;
                    case 14:
                        faceHeading(IRobot.SOUTH);
                        break;
                    case 15:
                        faceHeading(IRobot.WEST);
                        break;
                    default:
                        return 0;
                  }
              default:
                  return 0;
            }
            break;
        case 2:                                              // same logic as above
            switch(casenumberinside) {
              case 5:
                  if (rand3==1) {
                    faceHeading(IRobot.NORTH);
                  }else {faceHeading(IRobot.WEST);
                    }
                  break;
              case 6:
                  faceHeading(IRobot.NORTH);
                  break;
              case 7:
                  faceHeading(IRobot.WEST);
                  break;
              case 8:
                  switch(casenumberinside) {
                    case 9:
                        if (rand3==1) {
                          faceHeading(IRobot.SOUTH);
                        }else {faceHeading(IRobot.EAST);
                          }
                        break;
                    case 10:
                        faceHeading(IRobot.SOUTH);
                        break;
                    case 11:
                        faceHeading(IRobot.EAST);
                        break;
                    default:
                        return 0;
                  }
              default:
                  return 0;
            }
            break;
        case 3:
            switch(casenumberinside) {
              case 9:
                  if (rand3==1) {
                    faceHeading(IRobot.SOUTH);
                  }else {faceHeading(IRobot.EAST);
                    }
                  break;
              case 10:
                  faceHeading(IRobot.SOUTH);
                  break;
              case 11:
                  faceHeading(IRobot.EAST);
                  break;
              case 12:
                  switch(casenumberinside) {
                    case 5:
                        if (rand3==1) {
                          faceHeading(IRobot.NORTH);
                        }else {faceHeading(IRobot.WEST);
                          }
                        break;
                    case 6:
                        faceHeading(IRobot.NORTH);
                        break;
                    case 7:
                        faceHeading(IRobot.WEST);
                        break;
                    default:
                        return 0;
                  }
              default:
                  return 0;
            }
            break;
        case 4:
            switch(casenumberinside) {
              case 13:
                  if (rand3==1) {
                    faceHeading(IRobot.SOUTH);
                  }else {faceHeading(IRobot.WEST);
                    }
                  break;
              case 14:
                  faceHeading(IRobot.SOUTH);
                  break;
              case 15:
                  faceHeading(IRobot.WEST);
                  break;
              case 16:
                  switch(casenumberinside) {
                    case 1:
                        if (rand3==1) {
                          faceHeading(IRobot.NORTH);
                        }else {faceHeading(IRobot.EAST);
                          }
                        break;
                    case 2:
                        faceHeading(IRobot.NORTH);
                        break;
                    case 3:
                        faceHeading(IRobot.EAST);
                        break;
                    default:
                        return 0;
                  }
              default:
                  return 0;
            }
            break;

        case 5:                                             //the target is to the north of the robot
            if (north==1) {                                 //if there isn't a wall in the north
              faceHeading(IRobot.NORTH);                    //face north
            }else {
              switch (casenumberinside) {
                case 17:                                    //all three directions are available
                    switch (rand4) {                        //randomly pick one direction out of three
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        case 2:
                            faceHeading(IRobot.NORTH);
                            break;
                        default:
                              return 0;
                      }
                case 18:                                     //east is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.SOUTH);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        default:
                            return 0;
                    }
                case 19:                                     //south is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        default:
                            return 0;
                    }
                case 20:                                     //west is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.SOUTH);
                            break;
                        default:
                            return 0;
                    }
                case 21:                                     //only east is available
                    faceHeading(IRobot.EAST);
                    break;
                case 22:                                     //only south is available
                    faceHeading(IRobot.SOUTH);
                    break;
                case 23:                                     //only west is available
                    faceHeading(IRobot.WEST);
                    break;
              }
            }
        case 7:                                             //the target is to the east of the robot
            if (east==1) {                                 //if there isn't a wall in the east
              faceHeading(IRobot.EAST);                    //face east
            }else {
              switch (casenumberinside) {
                case 24:                                    //all three directions are available
                    switch (rand4) {                        //randomly pick one direction out of three
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        case 2:
                            faceHeading(IRobot.NORTH);
                            break;
                        default:
                              return 0;
                      }
                case 25:                                     //north is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.SOUTH);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        default:
                            return 0;
                    }
                case 26:                                     //south is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.NORTH);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        default:
                            return 0;
                    }
                case 27:                                     //west is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.NORTH);
                            break;
                        case 1:
                            faceHeading(IRobot.SOUTH);
                            break;
                        default:
                            return 0;
                    }
                case 28:                                     //only north is available
                    faceHeading(IRobot.NORTH);
                    break;
                case 29:                                     //only south is available
                    faceHeading(IRobot.SOUTH);
                    break;
                case 30:                                     //only west is available
                    faceHeading(IRobot.WEST);
                    break;
              }
            }
        case 6:                                             //the target is to the south of the robot
            if (south==1) {                                 //if there isn't a wall in the south
              faceHeading(IRobot.SOUTH);                    //face south
            }else {
              switch (casenumberinside) {
                case 31:                                    //all three directions are available
                    switch (rand4) {                        //randomly pick one direction out of three
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        case 2:
                            faceHeading(IRobot.NORTH);
                            break;
                        default:
                              return 0;
                      }
                case 32:                                     //north is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        default:
                            return 0;
                    }
                case 33:                                     //east is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.NORTH);
                            break;
                        case 1:
                            faceHeading(IRobot.WEST);
                            break;
                        default:
                            return 0;
                    }
                case 34:                                     //west is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.NORTH);
                            break;
                        case 1:
                            faceHeading(IRobot.EAST);
                            break;
                        default:
                            return 0;
                    }
                case 35:                                     //only north is available
                    faceHeading(IRobot.NORTH);
                    break;
                case 36:                                     //only east is available
                    faceHeading(IRobot.EAST);
                    break;
                case 37:                                     //only west is available
                    faceHeading(IRobot.WEST);
                    break;
              }
            }
        case 8:                                             //the target is to the west of the robot
            if (west==1) {                                 //if there isn't a wall in the west
              faceHeading(IRobot.WEST);                    //face west
            }else {
              switch (casenumberinside) {
                case 38:                                    //all three directions are available
                    switch (rand4) {                        //randomly pick one direction out of three
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.SOUTH);
                            break;
                        case 2:
                            faceHeading(IRobot.NORTH);
                            break;
                        default:
                              return 0;
                      }
                case 39:                                     //north is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.EAST);
                            break;
                        case 1:
                            faceHeading(IRobot.SOUTH);
                            break;
                        default:
                            return 0;
                    }
                case 40:                                     //east is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.NORTH);
                            break;
                        case 1:
                            faceHeading(IRobot.SOUTH);
                            break;
                        default:
                            return 0;
                    }
                case 41:                                     //south is unavailable
                    switch (rand3) {
                        case 0:
                            faceHeading(IRobot.NORTH);
                            break;
                        case 1:
                            faceHeading(IRobot.EAST);
                            break;
                        default:
                            return 0;
                    }
                case 42:                                     //only north is available
                    faceHeading(IRobot.NORTH);
                    break;
                case 43:                                     //only east is available
                    faceHeading(IRobot.EAST);
                    break;
                case 44:                                     //only south is available
                    faceHeading(IRobot.SOUTH);
                    break;
              }
            }
          default:
                return 0;
          }return 0;
      }






    // this method returns a description of this controller
    public String getDescription() {
       return "A controller which homes in on the target";
    }

    // sets the delay
    public void setDelay(int millis) {
       delay = millis;
    }

    // gets the current delay
    public int getDelay() {
       return delay;
    }

    // stops the controller
    public void reset() {
       active = false;
    }

    // sets the reference to the robot
    public void setRobot(IRobot robot) {
       this.robot = robot;
    }
}
